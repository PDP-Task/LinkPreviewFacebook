package uz.context.facebooktimeline.model

data class Post (
    val imageView: String,
    val title: String,
    val description: String
)