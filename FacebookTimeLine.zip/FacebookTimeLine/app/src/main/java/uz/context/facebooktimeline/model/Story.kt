package uz.context.facebooktimeline.model

data class Story(
    val image: Int,
    val title: String
)