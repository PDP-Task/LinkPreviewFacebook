package uz.context.facebooktimeline.util

interface OnClickListener {
    fun onClick(url: String, title: String, des: String)
}